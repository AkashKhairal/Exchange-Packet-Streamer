﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Buffers.Binary; 
using System.Text.Json;

public class Program
{
    public static void Main()
    {
        
        List<ExchangePacket> allPackets = GetAllPackets();
        Console.WriteLine($"[INFO] Received {allPackets.Count} packets from the initial stream.");

        
        List<int> missingSequences = FindMissingSequences(allPackets);
        if (missingSequences.Any())
        {
            Console.WriteLine($"[INFO] Missing sequences detected: {string.Join(", ", missingSequences)}");
        }
        else
        {
            Console.WriteLine("[INFO] No missing sequences detected.");
        }

        if (missingSequences.Count > 0)
        {
  
            List<ExchangePacket> missingPackets = RequestMissingPackets(missingSequences);
            Console.WriteLine($"[INFO] Retrieved {missingPackets.Count} missing packets.");

 
            allPackets.AddRange(missingPackets);
        }

       
        WritePacketsToJson(allPackets, "all_packets.json");
        Console.WriteLine("[INFO] Done! Check 'all_packets.json' for the complete data.");
    }


    private static List<ExchangePacket> GetAllPackets()
    {
        var packets = new List<ExchangePacket>();


        using TcpClient client = new TcpClient("127.0.0.1", 3000);
        using NetworkStream stream = client.GetStream();

        byte[] request = { 1, 0 };
        stream.Write(request, 0, request.Length);
        stream.Flush();


        byte[] buffer = new byte[17];
        while (true)
        {
            int bytesRead = ReadExactly(stream, buffer, 17);
            if (bytesRead < 17)
            {

                break;
            }
            packets.Add(ParsePacket(buffer));
        }

        return packets;
    }

    private static List<int> FindMissingSequences(List<ExchangePacket> packets)
    {
        if (packets.Count == 0) return new List<int>();

        int minSeq = packets.Min(p => p.Sequence);
        int maxSeq = packets.Max(p => p.Sequence);

        HashSet<int> existingSequences = packets.Select(p => p.Sequence).ToHashSet();
        var missing = new List<int>();

        for (int seq = minSeq; seq <= maxSeq; seq++)
        {
            if (!existingSequences.Contains(seq))
            {
                missing.Add(seq);
            }
        }

        return missing;
    }

    private static List<ExchangePacket> RequestMissingPackets(List<int> missingSequences)
    {
        var missingPackets = new List<ExchangePacket>();

        using TcpClient client = new TcpClient("127.0.0.1", 3000);
        using NetworkStream stream = client.GetStream();

        foreach (int seq in missingSequences)
        {

            byte[] request = { 2, (byte)seq };
            stream.Write(request, 0, request.Length);
            stream.Flush();


            byte[] buffer = new byte[17];
            int bytesRead = ReadExactly(stream, buffer, 17);
            if (bytesRead < 17)
            {
                throw new Exception($"[ERROR] Server did not send 17 bytes for seq={seq}.");
            }

            missingPackets.Add(ParsePacket(buffer));
        }

        return missingPackets;
    }


    private static int ReadExactly(NetworkStream stream, byte[] buffer, int length)
    {
        int totalRead = 0;
        while (totalRead < length)
        {
            int read = stream.Read(buffer, totalRead, length - totalRead);
            if (read == 0) 
            {
                break;
            }
            totalRead += read;
        }
        return totalRead;
    }

    private static ExchangePacket ParsePacket(byte[] buffer)
    {
        string symbol = Encoding.ASCII.GetString(buffer, 0, 4); 
        char buySell = (char)buffer[4];                        

        int quantity = BinaryPrimitives.ReadInt32BigEndian(buffer.AsSpan(5, 4));
        int price = BinaryPrimitives.ReadInt32BigEndian(buffer.AsSpan(9, 4));
        int sequence = BinaryPrimitives.ReadInt32BigEndian(buffer.AsSpan(13, 4));

        return new ExchangePacket
        {
            Symbol = symbol,
            BuySell = buySell,
            Quantity = quantity,
            Price = price,
            Sequence = sequence
        };
    }


    private static void WritePacketsToJson(List<ExchangePacket> packets, string filePath)
    {
        var ordered = packets.OrderBy(p => p.Sequence).ToList();

       
        var options = new JsonSerializerOptions { WriteIndented = true };
        string json = JsonSerializer.Serialize(ordered, options);

        File.WriteAllText(filePath, json);
    }
}

public class ExchangePacket
{
    public string Symbol { get; set; }  
    public char BuySell { get; set; }   
    public int Quantity { get; set; }
    public int Price { get; set; }
    public int Sequence { get; set; }
}
